Kanna Kamui (Miss Kobayashi's Dragon Maid) MMD
Modeled by icemega5

Her jacket is a tricky thing to work with. I created some adjustment bones so incase there's some disgusting clipping or bad weights, use those to adjust them.

What I forbid:

Do not sell this model for profit. It is only use for fan-art and nothing else
Do not use this model for commercial purpose
Do not claim this model as your own
No re-distribution

-----

Use my work responsibly. I can not be held responsible for any damages caused by this model.

Exceptions:

You may edit & take parts from Kanna. However, distribution of parts from this model is sololy forbidden.

Credit me as icemega5 if you are going to use this model.

Ver. 1.01
Fixed a morph error of her dark slider clipping through her face

Ver. 1.02
Improve the sock textures a little bit
Fixed a error on the dark slider being on by default by accident

Ver. 1.03
Added additional bones for better control for the teeth, tongue and eye brow.


You can find me at twitter
https://twitter.com/icemega5