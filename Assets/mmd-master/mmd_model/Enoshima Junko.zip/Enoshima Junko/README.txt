Enoshima Junko
Super High School Level Despair!
I worked hard on this model
Please do no edit/redistribute c:

Junko Enoshima (C) Spike Chunsoft